#include <stdio.h>
#include <stdlib.h>

/*Desenvolva um programa em linguagem C que aloque dinamicamente um vetor de 10 elementos
do tipo inteiro.
Preencha o vetor com valores aleat�rios.
Em seguida, apresente todos os elementos utilizando aritm�tica de ponteiros (sem o uso de
nota��o de �ndice).
Observa��o: A aloca��o de mem�ria deve ser realizada utilizando malloc.*/

int main (){
	
	int *vetor1, x;
	
	vetor1=malloc(10*sizeof(int));
	
	for (x=0;x<10;x++){
		vetor1[x] = rand () % 100;
		printf ("%d\n", *(vetor1+x));
	}
	


}
